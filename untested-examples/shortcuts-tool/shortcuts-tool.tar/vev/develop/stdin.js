var packageBuild = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target, mod));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // globals:react
  var require_react = __commonJS({
    "globals:react"(exports, module) {
      module.exports = React;
    }
  });

  // globals:@vev/react
  var require_react2 = __commonJS({
    "globals:@vev/react"(exports, module) {
      module.exports = Vev;
    }
  });

  // src/____index.js
  var index_exports = {};
  __export(index_exports, {
    ShortcutsPresenter: () => ShortcutsPresenter_default
  });

  // src/ShortcutsPresenter.tsx
  var import_react2 = __toESM(require_react());

  // src/ShortcutsPresenter.module.css
  var ShortcutsPresenter_module_default = { "wrapper": "3SFSs2i1GpLdAYfn2Cp8__shortcuts-tool_src__wrapper", "keysContainer": "3SFSs2i1GpLdAYfn2Cp8__shortcuts-tool_src__keysContainer", "keyboardButton": "3SFSs2i1GpLdAYfn2Cp8__shortcuts-tool_src__keyboardButton" };

  // src/helpers/use-multi-key-press.tsx
  var import_react = __toESM(require_react());
  function useMultiKeyPress({ keyDelay }) {
    const [keysPressed, setKeyPressed] = (0, import_react.useState)({});
    function downHandler({ key }) {
      keysPressed[key] = 1;
      setKeyPressed(Object.assign({}, keysPressed));
    }
    __name(downHandler, "downHandler");
    const upHandler = /* @__PURE__ */ __name(({ key }) => {
      setTimeout(() => {
        keysPressed[key] = 0;
        delete keysPressed[key];
        setKeyPressed(Object.assign({}, keysPressed));
      }, keyDelay);
    }, "upHandler");
    (0, import_react.useEffect)(() => {
      window.addEventListener("keydown", downHandler);
      window.addEventListener("keyup", upHandler);
      return () => {
        window.removeEventListener("keydown", downHandler);
        window.removeEventListener("keyup", upHandler);
      };
    }, []);
    return keysPressed;
  }
  __name(useMultiKeyPress, "useMultiKeyPress");

  // src/ShortcutsPresenter.tsx
  var import_react3 = __toESM(require_react2());
  var REMOVE_KEYS_DELAY = 1e4;
  var ShortcutsPresenter = /* @__PURE__ */ __name(({ title = "Vev" }) => {
    const keysPressed = useMultiKeyPress({ keyDelay: REMOVE_KEYS_DELAY });
    (0, import_react2.useEffect)(() => {
      console.log("Keys presssssed", keysPressed);
    }, [keysPressed]);
    return /* @__PURE__ */ import_react2.default.createElement("div", {
      className: ShortcutsPresenter_module_default.wrapper
    }, /* @__PURE__ */ import_react2.default.createElement("h1", null, "Keys pressed"), /* @__PURE__ */ import_react2.default.createElement("div", {
      className: ShortcutsPresenter_module_default.keysContainer
    }, Object.keys(keysPressed).map((key) => {
      return /* @__PURE__ */ import_react2.default.createElement("kbd", {
        key,
        className: ShortcutsPresenter_module_default.keyboardButton
      }, getKey(key));
    })));
  }, "ShortcutsPresenter");
  function getKey(key) {
    switch (key) {
      case "Shift":
        return "\u21E7SHIFT";
      default:
        return key;
    }
  }
  __name(getKey, "getKey");
  (0, import_react3.registerVevComponent)(ShortcutsPresenter, {
    name: "My Component",
    props: [{ name: "title", type: "string", initialValue: "Vev" }],
    editableCSS: [
      {
        selector: ShortcutsPresenter_module_default.wrapper,
        properties: ["background"]
      }
    ]
  });
  var ShortcutsPresenter_default = ShortcutsPresenter;
  return __toCommonJS(index_exports);
})();
